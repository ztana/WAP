11/27/2012
KL added a few comments about refactoring that could be done in the servlet.

8 April 2009KL
A solution to the Quiz Servlet lab of lesson 3 (April 09 and earlier) lab.  Not as fully functional as the 
one by Manrat, but better documentation practices and easier to understand the code.  Also includes a class,
TestRunner, that runs the quiz to the console using the same business classes as the web application.  
Also includes a JUnit test of the Quiz class.

If your solution for this lab is "problematic" then you may use this solution or parts
of it if you wish for your start to the JSP Quiz Lab if you wish.
